#!/bin/bash

# Set project directory
PROJECT_DIR="$(dirname "$(realpath "$0")")"
LOG_DIR="$PROJECT_DIR/logs"

# Ensure logs directory exists
mkdir -p "$LOG_DIR"

# Run AI-powered setup validation
python3 "$PROJECT_DIR/setup_tata_ai.py"
STATUS=$?

if [ $STATUS -eq 1 ]; then
    echo "[ERROR] Dependencies are missing. Install them and retry."
    exit 1
elif [ $STATUS -eq 2 ]; then
    echo "[WARNING] Some services are missing. Rebuilding..."
    docker-compose up -d --build
    echo "[INFO] Services restarted. Checking again..."
    sleep 10
    python3 "$PROJECT_DIR/setup_tata_ai.py"
    if [ $? -ne 0 ]; then
        echo "[ERROR] Services failed to restart. Check logs for details."
        exit 1
    fi
fi

# Start services normally
echo "[INFO] Starting Tata AI..."
docker-compose up -d

# Display logs and monitor
docker-compose logs -f > "$LOG_DIR/tata_ai.log" 2>&1 &
echo "[INFO] Logs are being written to $LOG_DIR/tata_ai.log"

echo "[INFO] Tata AI is up and running."

# Monitor health of each service
echo "[INFO] Checking service health..."
docker ps --format "table {{.Names}}\t{{.Status}}"
